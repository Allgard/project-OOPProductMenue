import java.util.ArrayList;
import java.util.Scanner;
// Das ist die Klasse für das Gesamtkonstrukt für das Projekt: PC-Shop
public class MainShop {
    // ArrayList<> für die Produkte
    static ArrayList<Produkt> produkte = new ArrayList<>();
    // Scanner für Benutzereingaben
    static Scanner sc = new Scanner(System.in);
    static void main(String[] args) {
        // Methodenaufrufe
        dummieData();
        hauptMenue();
    }
    // Hilfsmethode: Wenn der Benutzer etwas anderes als eine Ganzzahl eingibt (z.B. Buchstaben), wird nicht das Programm abstürzen.
    // Stattdessen kommt: "Fehlerhafte Eingabe" und der Benutzer darf es erneut versuchen.
    static int leseInt() {
        while (true) {
            // Try u. Catch verhindert Abstürze
            // Versuch das
            try {
                return Integer.parseInt(sc.next());
            }
            // wenn Fehler --> mach das
            catch (Exception e) {
                System.out.println("Fehlerhafte Eingabe");
            }
        }
    }
    // Hilfsmethode: Wenn der Benutzer etwas anderes als eine Zahl/Kommazahl eingibt (z.B. Buchstaben), wird nicht das Programm abstürzen.
    // Stattdessen kommt: "Fehlerhafte Eingabe" und der Benutzer darf es erneut versuchen.
    static double leseDouble() {
        while (true) {
            try {
                return Double.parseDouble(sc.next());
            } catch (Exception e) {
                System.out.println("Fehlerhafte Eingabe");
            }
        }
    }
    // Das ist das Hauptmenü mit einem if-else Konstrukt für die Menüpunkte
    static void hauptMenue() {
        int auswahl;
        // Ausgabe Menüpunkte
        System.out.println("\n-----------------------------------------------------------------------------------" +
                "\nPC-Shop" +
                "\t\t\t\t\tHauptmenü" +
                "\t\t\t\t\t\t\tvon:" +
                "\tKevin Bonowski" +
                "\n-----------------------------------------------------------------------------------" +
                "\n1) Produkt anlegen" +
                "\n2) Produkt bearbeiten" +
                "\n3) Produkt suchen" +
                "\n4) Produkt löschen" +
                "\n0) Shop beenden" +
                "\n-----------------------------------------------------------------------------------");
        // Ausgabe für die Auswahl
        System.out.print("Bitte wählen: ");
        auswahl = sc.nextInt();
        // Menue läuft so lange, bis der Benutzer 0 eingibt
        if (auswahl == 1) {produktAnlegen(); hauptMenue();}
        else if (auswahl == 2) {produktBearbeiten();}
        else if (auswahl == 3) {produktSuchen();}
        else if (auswahl == 4) {produktLoeschen(); hauptMenue();}
        else if (auswahl == 0) {shopBeenden();}
        else {System.out.println("Fehlerhafte Eingabe"); hauptMenue();}
    }
    // Das ist der Menüpunkt um ein Produkt anzulegen
    static void produktAnlegen() {
        System.out.println("1) Monitor 2) Motherboard 3) Tastatur 4) Maus");
        int kategorie = leseInt();
        // Abfrage des Markennamen
        System.out.print("Marke: ");
        String marke = sc.next();
        // Abfrage des Modellnamen
        System.out.print("Modell: ");
        String modell = sc.next();
        // Abfrage des Preises
        System.out.print("Preis: ");
        double preis = leseDouble();

        if (marke.isEmpty() || modell.isEmpty()) {
            System.out.println("Produkt konnte aufgrund leerer Eingabewerte nicht gespeichert werden");
            return;
        }

        Produkt p;

        if (kategorie == 1) {
            // Abfrage der Zollgröße für den Monitor (z.B. 34)
            System.out.print("Zoll: ");
            double zoll = leseDouble();
            p = new Monitor(marke, modell, preis, zoll);
        } else if (kategorie == 2) {
            // Abfrage der Bauform vom Mainbord (z.B. ATX)
            System.out.print("Bauform: ");
            String bauform = sc.next();
            // Wenn die Eingabe leer gelassen wird kann das Produkt nicht abgespeichert werden
            if (bauform.isEmpty()) {
                System.out.println("Produkt konnte aufgrund leerer Eingabewerte nicht gespeichert werden");
                return;
            }

            p = new Motherboard(marke, modell, preis, bauform);
        } else if (kategorie == 3) {
            // Abfrage via Boolean deutsches/englisches Tastaturlayout J/N
            System.out.print("Deutsch (1 = ja, 0 = nein): ");
            int de = leseInt();

            System.out.print("Englisch (1 = ja, 0 = nein): ");
            int en = leseInt();

            p = new Tastatur(marke, modell, preis, de == 1, en == 1);
        } else if (kategorie == 4) {
            // Abfrage des DPI Wertes von der Maus
            System.out.print("DPI: ");
            double dpi = leseDouble();
            p = new Maus(marke, modell, preis, dpi);
        } else {
            System.out.println("Fehlerhafte Eingabe");
            return;
        }

        produkte.add(p);
        System.out.println("Produkt gespeichert!");

        // Optional: weiter bearbeiten?
        System.out.print("Weiteres Produkt anlegen? (j/n): ");
        String weiter = sc.next().toLowerCase();

        if (!weiter.equals("j")) {
            hauptMenue();
        }
    }
    // Das ist der Menüpunkt um ein Produkt zu bearbeiten
    static void produktBearbeiten() {
        if (produkte.isEmpty()) {
            System.out.println("Keine Produkte vorhanden");
            hauptMenue(); // zurück ins Menü
            return;
        }

        while (true) {
            // Produkte anzeigen (nummeriert ab 1)
            for (int i = 0; i < produkte.size(); i++) {
                Produkt p = produkte.get(i);
                System.out.println((i +1) + ") " +
                        p.getMarke() + " " +
                        p.getModell() + " " +
                        p.getPreis());
            }

            System.out.print("Produkt wählen: ");
            int index = leseInt() - 1; // wegen Anzeige ab 1

            if (index < 0 || index >= produkte.size()) {
                System.out.println("Fehlerhafte Eingabe");
                continue; // erneut versuchen
            }

            Produkt produkt = produkte.get(index);

            System.out.print("Neue Marke: ");
            String marke = sc.next();

            System.out.print("Neues Modell: ");
            String modell = sc.next();

            System.out.print("Neuer Preis: ");
            double preis = leseDouble();

            if (marke.isEmpty() || modell.isEmpty()) {
                System.out.println("Produkt konnte aufgrund leerer Eingabewerte nicht gespeichert werden");
                return;
            }

            produkt.setMarke(marke);
            produkt.setModell(modell);
            produkt.setPreis(preis);

            // Typ-Spezifische Bearbeitung
            //          Typ Prüfen
            if (produkt instanceof Monitor) {
                //          Casting
                Monitor m = (Monitor) produkt;
                System.out.print("Neue Zollgröße: ");
                double zoll = leseDouble();
                m.setZoll(zoll);
            } else if (produkt instanceof Maus) {
                Maus m = (Maus) produkt;
                System.out.print("Neuen DPI Wert: ");
                double dpi = leseDouble();
                m.setDpi(dpi);
            } else if (produkt instanceof Motherboard) {
                Motherboard m = (Motherboard) produkt;
                System.out.print("Neue Bauform: ");
                String bauform = sc.next();
                m.setBauform(bauform);
            } else if (produkt instanceof Tastatur) {
                Tastatur t = (Tastatur) produkt;
                System.out.print("Deutsches Layout (1/0): ");
                int de = leseInt();
                System.out.print("Englisches Layout (1/0): ");
                int en = leseInt();

                t.setDe(de == 1);
                t.setEn(en == 1);
            }

            System.out.println("Produkt aktualisiert!");

            // Optional: weiter bearbeiten?
            System.out.print("Weiteres Produkt bearbeiten? (j/n): ");
            String weiter = sc.next().toLowerCase();

            if (!weiter.equals("j")) {
                produktBearbeiten();
                return;
            }
        }
    }
    // Das ist der Menüpunkt um ein Produkt zu suchen
    static void produktSuchen() {
        if (produkte.isEmpty()) {
            System.out.println("Keine Produkte vorhanden");
            return;
        }

        boolean weiter = true;

        while (weiter) {
            System.out.print("Suchbegriff: ");
            String such = sc.next().toLowerCase();

            boolean gefunden = false;
            int trefferNummer = 1;

            for (int i = 0; i < produkte.size(); i++) {
                Produkt p = produkte.get(i);
                String alleEigenschaften = p.getMarke().toLowerCase() + " "
                        + p.getModell().toLowerCase() + " "
                        + p.getPreis() + " ";
                // Typ-spezifische Eigenschaften
                if (p instanceof Monitor) {
                    alleEigenschaften += ((Monitor) p).getZoll() + " ";
                } else if (p instanceof Motherboard) {
                    alleEigenschaften += ((Motherboard) p).getBauform().toLowerCase() + " ";
                } else if (p instanceof Tastatur) {
                    alleEigenschaften += (((Tastatur) p).isDe() ? "de " : "") +
                            (((Tastatur) p).isEn() ? "en " : "");
                } else if (p instanceof Maus) {
                    alleEigenschaften += ((Maus) p).getDpi() + " ";
                }
                // Suche prüfen
                if (alleEigenschaften.contains(such)) {
                    System.out.println(trefferNummer + ") " + p); // nutzt toString()
                    trefferNummer++;
                    gefunden = true;
                }
            }
            if (!gefunden) {System.out.println("Keine Treffer gefunden");}
        }

        // Wiederholung abfragen
        System.out.print("Erneut suchen? (j/n): ");
        String eingabe = sc.next().toLowerCase();

        if (eingabe.equals("j")) {
            // Schleife läuft einfach weiter
        } else if (eingabe.equals("n")) {
            weiter = false;
            hauptMenue(); // zurück ins Menü
        } else {
            System.out.println("Fehlerhafte Eingabe!");
            weiter = false;
            hauptMenue(); // zurück ins Menü
        }
    }
    // Das ist der Menüpunkt um ein Produkt zu löschen
    static void produktLoeschen() {
        if (produkte.isEmpty()) {
            System.out.println("Keine Produkte vorhanden.");
            return; // zurück ins Menü
        }

        // Produkte anzeigen
        for (int i = 0; i < produkte.size(); i++) {
            System.out.println((i + 1) + ") " + produkte.get(i));
        }

        // Abfrage welches Produkt gelöscht werden soll
        System.out.println("Welches Produkt möchten Sie löschen? ");

        // Eingabe prüfen
        if (!sc.hasNextInt()) {
            System.out.println("Fehlerhafte Eingabe!");
            sc.nextLine(); // falsche Eingabe verwerfen
            return;
        }
        int eingabe = sc.nextInt();
        sc.nextLine(); // Puffer leeren!

        // Umwandlung von 1-basiert zu 0-basiert
        int index = eingabe - 1;

        // Index prüfen
        if (index < 0 || index >= produkte.size()) {
            System.out.println("Fehlerhafte Eingabe!");
            return;
        }

        // Sicherheitscheck
        System.out.println("Möchten Sie das Produkt wirklich löschen (j/n)?");
        String antwort = sc.nextLine();
        if (antwort.trim().equalsIgnoreCase("j")) {
            Produkt p = produkte.remove(index);
            System.out.println(p.getMarke() + ", " + p.getModell() + " wurde gelöscht.");
        } else {
            System.out.println("Löschen abgebrochen.");
        }

        // Optional: weiter bearbeiten?
        System.out.print("Weiteres Produkt löschen? (j/n): ");
        String weiter = sc.next().toLowerCase();

        if (!weiter.equals("j")) {
            hauptMenue();
            return;
        }
    }
    static void shopBeenden() {
        while (true) {
            System.out.println("Möchten Sie den Shop wirklich beenden? (j/n)");
            String eingabe = sc.next().toLowerCase();

            if (eingabe.equals("j")) {
                System.out.println("PC Shop wurde beendet");
                System.exit(0);
            } else if (eingabe.equals("n")) {
                hauptMenue();
                break; // Schleife beenden
            } else {System.out.println("Fehlerhafte Eingabe!");}
        }
    }
    static void dummieData() {
        produkte.add(new Monitor("Samsung", "S27C390EAU_Curved", 139.90, 27));
        produkte.add(new Motherboard("Gigabyte", "MZ73-LM0_REV_2.0", 1932.00, "E-ATX"));
        produkte.add(new Maus("Evoluent", "4_Vertikale", 108.18, 2600));
        produkte.add(new Tastatur("Logitech", "ERGO_K860", 99.99, true, false));
        produkte.add(new Monitor("Acer", "SA2_Series", 109.90, 24));
    }
}